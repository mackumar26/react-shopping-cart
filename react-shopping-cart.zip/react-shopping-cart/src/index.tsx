import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import PageHeader from './Header/PageHeader';
import PageFooter from './Footer/PageFooter';
import { QueryClient, QueryClientProvider } from 'react-query';


const client = new QueryClient();

ReactDOM.render(
  
  <QueryClientProvider client={client}>
    <PageHeader/>
    <App />
    <PageFooter/>
  </QueryClientProvider>,
  document.getElementById('root')
);
