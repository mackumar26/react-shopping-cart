import styled from 'styled-components';
import IconButton from '@material-ui/core/IconButton';

export const Wrapper = styled.div`
  margin: 40px;
`;

export const StyledButton = styled(IconButton)`
  position: fixed;
  z-index: 100;
  // right: 20px;
  // top: 20px;
  top: 0.5%;
  right:0.5%;
  background-color: #e7e7e7; 
  color: black;
`;
